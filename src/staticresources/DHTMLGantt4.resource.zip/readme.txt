/*
@license

dhtmlxGantt v.4.0.0 Professional
This software is covered by DHTMLX Enterprise License. Usage without proper license is prohibited.

(c) Dinamenta, UAB.
*/


Useful links
-------------

- Online  documentation
	http://docs.dhtmlx.com/gantt/

- Downloadable documentation
	CHM version
		http://dhtmlx.com/x/download/regular/dhtmlxgantt_chm.zip
	HTML version
		http://dhtmlx.com/x/download/regular/dhtmlxgantt_docs_html.zip
	
- Support forum
	http://forum.dhtmlx.com/viewforum.php?f=15