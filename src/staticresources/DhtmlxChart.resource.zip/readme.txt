dhtmlxChart v.4.1.3 Standard edition

(c) Dinamenta, UAB.